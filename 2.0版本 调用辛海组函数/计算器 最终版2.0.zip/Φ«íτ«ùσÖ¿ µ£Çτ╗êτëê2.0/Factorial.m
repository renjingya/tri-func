function Factorial_Result=Factorial(nn)
  sum=1;
  for i=1:nn
      sum=sum*i;
  end
  Factorial_Result=sum;
end